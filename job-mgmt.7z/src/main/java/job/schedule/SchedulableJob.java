package job.schedule;

public interface SchedulableJob {

    void run() throws Exception;

}
